# ChesscomPgnExporter

This powershell script allows you to export all your chess.com games in a single PGN file.

Steps : 
1. Download this repository (Code -> Download zip) / Clone if you have some git knowledges
2. When the file ``ChesscomPgnExporter.ps1`` is on your PC, run it (On windows, right-click, click on ``run with Powershell``)
   ![Run](./run.PNG)
3. Type your chesscom username, press ``<<Enter>>``, wait a bit
   ![Search](./search.PNG)
4. A file named ``chess_com_games_username.pgn`` should be created in your ``Downloads`` folder